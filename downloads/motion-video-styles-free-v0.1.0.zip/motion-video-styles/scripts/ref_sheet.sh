#!/usr/bin/env bash
# Turn a reference video into a 4x4 contact sheet of 16 evenly spaced, timestamped frames,
# so its style can be analysed at a glance. Usage: ref_sheet.sh input.mp4 [out.png]
set -euo pipefail
IN="$1"; OUT="${2:-${IN%.*}-sheet.png}"
TMP=$(mktemp -d)
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN")
FONT=$(fc-match -f '%{file}' 'Noto Sans CJK SC:bold' 2>/dev/null || true)
i=0
for t in $(python3 -c "print(' '.join(str(round($D*(k+0.5)/16,2)) for k in range(16)))"); do
  ffmpeg -nostdin -y -loglevel error -ss "$t" -i "$IN" -frames:v 1 \
    -vf "scale=400:400:force_original_aspect_ratio=decrease,pad=400:400:(ow-iw)/2:(oh-ih)/2:black${FONT:+,drawtext=fontfile=$FONT:text='$t':x=4:y=4:fontsize=16:fontcolor=white:box=1:boxcolor=black@0.6}" \
    "$TMP/$(printf %02d $i).png"
  i=$((i+1))
done
ffmpeg -nostdin -y -loglevel error -i "$TMP/%02d.png" -vf tile=4x4 "$OUT"
rm -rf "$TMP"
echo "$OUT"
