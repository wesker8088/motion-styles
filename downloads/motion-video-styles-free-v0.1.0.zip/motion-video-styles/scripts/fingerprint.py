#!/usr/bin/env python3
"""Measure a video's style fingerprint: cuts per 10 s, mean frame difference, luminance, saturation, palette.
Compare your sample against the style's reference clip (fetch_ref.sh) — numbers far apart mean the look or
the rhythm drifted. Usage: fingerprint.py video.mp4 [reference.mp4] [--json]"""
import json, subprocess, sys, re
import numpy as np

def ff(args):
    return subprocess.run(["ffmpeg", "-nostdin", "-hide_banner", *args], capture_output=True, text=True).stderr

def duration(p):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p],
                                capture_output=True, text=True).stdout.strip())

def frames(p, n=12, w=96):
    d = duration(p); out = []
    for k in range(n):
        t = d * (k + 0.5) / n
        raw = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-ss", f"{t:.3f}", "-i", p, "-frames:v", "1",
                              "-vf", f"scale={w}:-2", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
        if raw:
            out.append(np.frombuffer(raw, np.uint8).reshape(-1, w, 3))
    return out

def palette(px, k=5, it=12):
    rng = np.random.default_rng(0)
    c = px[rng.choice(len(px), k, replace=False)].astype(float)
    for _ in range(it):
        lab = np.argmin(((px[:, None] - c[None]) ** 2).sum(-1), 1)
        c = np.array([px[lab == i].mean(0) if (lab == i).any() else c[i] for i in range(k)])
    share = np.bincount(lab, minlength=k) / len(px)
    o = np.argsort(-share)
    return [("#%02X%02X%02X" % tuple(int(v) for v in c[i]), round(float(share[i]), 2)) for i in o]

def measure(p):
    d = duration(p)
    cuts = len(re.findall(r"pts_time", ff(["-i", p, "-vf", "select='gt(scene,0.25)',showinfo", "-f", "null", "-"])))
    yavg = [float(x) for x in re.findall(r"YAVG=([\d.]+)", ff(["-i", p, "-vf",
            "tblend=all_mode=difference,signalstats,metadata=print:key=lavfi.signalstats.YAVG", "-f", "null", "-"]))]
    fr = frames(p)
    px = np.concatenate([f.reshape(-1, 3) for f in fr]).astype(float)
    mx, mn = px.max(1), px.min(1)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1), 0)
    lum = (0.2126 * px[:, 0] + 0.7152 * px[:, 1] + 0.0722 * px[:, 2]) / 255
    sub = px[:: max(1, len(px) // 20000)]
    hot = px[(sat > 0.45) & (mx > 60)]
    accent = None
    if len(hot) > 0.003 * len(px):
        hc = palette(hot[:: max(1, len(hot) // 5000)], k=2)
        accent = (hc[0][0], round(len(hot) / len(px), 3))
    return {"file": p, "dur_s": round(d, 1), "cuts_per_10s": round(cuts / d * 10, 1),
            "frame_diff": round(float(np.mean(yavg)) if yavg else 0, 1),
            "frame_diff_p95": round(float(np.percentile(yavg, 95)) if yavg else 0, 1),
            "luma": round(float(lum.mean()), 2), "dark_share": round(float((lum < 0.25).mean()), 2),
            "sat": round(float(sat.mean()), 2), "palette": palette(sub), "accent": accent}

def line(m):
    pal = " ".join(f"{h}({s:.0%})" for h, s in m["palette"])
    return (f"cuts/10s {m['cuts_per_10s']} · frame-diff {m['frame_diff']} (p95 {m['frame_diff_p95']}) · "
            f"luma {m['luma']} · dark {m['dark_share']:.0%} · sat {m['sat']} · palette {pal}"
            + (f" · accent {m['accent'][0]}({m['accent'][1]:.1%} saturated px)" if m["accent"] else " · accent none"))

if __name__ == "__main__":
    args = [x for x in sys.argv[1:] if not x.startswith("--")]
    if not args: sys.exit(__doc__)
    a = measure(args[0]); print(line(a))
    if len(args) > 1:
        b = measure(args[1]); print("ref:", line(b))
        flags = []
        if b["cuts_per_10s"] and not (0.5 <= (a["cuts_per_10s"] + .5) / (b["cuts_per_10s"] + .5) <= 2): flags.append("cut rhythm differs >2×")
        if b["frame_diff"] and not (0.5 <= (a["frame_diff"] + .5) / (b["frame_diff"] + .5) <= 2): flags.append("motion energy differs >2×")
        if abs(a["luma"] - b["luma"]) > 0.2: flags.append("overall brightness differs (dark vs light film?)")
        if abs(a["sat"] - b["sat"]) > 0.2: flags.append("saturation differs (palette drifted?)")
        if bool(a["accent"]) != bool(b["accent"]): flags.append("accent colour present in one but not the other")
        elif a["accent"] and b["accent"] and a["accent"][1] > 3 * b["accent"][1] + 0.02: flags.append("accent covers far more area than the reference")
        print("drift:", "; ".join(flags) if flags else "none flagged (still check the DNA list by eye)")
    if "--json" in sys.argv: print(json.dumps(a, ensure_ascii=False))
