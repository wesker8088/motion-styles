#!/usr/bin/env bash
# Download a style's reference frame + 6 s clip from the public gallery and build a contact sheet,
# so you can LOOK at the style before building (and compare against it at self-check time).
# Usage: fetch_ref.sh <slug> [outdir=refs/<slug>]
set -euo pipefail
SLUG="$1"; OUT="${2:-refs/$SLUG}"
BASE="${MOTION_STYLES_BASE:-https://wesker8088.github.io/motion-styles}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$OUT"
ok=0
if curl -fsSL "$BASE/assets/frames/$SLUG.jpg" -o "$OUT/frame.jpg"; then echo "frame: $OUT/frame.jpg"; ok=1; else rm -f "$OUT/frame.jpg"; echo "no frame for $SLUG" >&2; fi
if curl -fsSL "$BASE/assets/clips/$SLUG.mp4" -o "$OUT/clip.mp4"; then
  echo "clip:  $OUT/clip.mp4"; ok=1
  bash "$HERE/ref_sheet.sh" "$OUT/clip.mp4" "$OUT/sheet.png" >/dev/null && echo "sheet: $OUT/sheet.png"
  PY="${PYTHON:-python3}"
  if "$PY" -c "import numpy" 2>/dev/null; then "$PY" "$HERE/fingerprint.py" "$OUT/clip.mp4" | tee "$OUT/fingerprint.txt"
  else echo "fingerprint skipped: $PY has no numpy (set PYTHON=/path/to/python3-with-numpy)" >&2; fi
else rm -f "$OUT/clip.mp4"; echo "no clip for $SLUG" >&2; fi
[ $ok = 1 ] || { echo "nothing found for $SLUG — check the slug, or work from the text entry only" >&2; exit 1; }
