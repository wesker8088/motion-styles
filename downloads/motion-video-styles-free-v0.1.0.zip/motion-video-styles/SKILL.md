---
name: motion-video-styles
description: Style library and production workflow for motion-graphics videos made in code (Remotion, HTML/Canvas, Three.js). FREE tier v0.1.0-free with 12 analysed styles (DNA + craft + intake + Remotion starter). Upgrade to full pack (~127 styles + complete scripts/templates) via license code on the install page. Use whenever the user wants to make, restyle or critique a code-rendered motion video.
---

# Motion Video Styles（免费档 v0.1.0-free）

本包是 **免费档**：12 个精选风格完整 DNA + 开工 SOP + craft + Remotion starter，够你装上、跑出一条不像抽卡的小样。

**风格数量：** 12（见 `references/styles.md`）  
**全量档：** 约 127 analysed 风格 + 完整 scripts / templates / custom-style 等 → 打开效果站安装页，输入兑换码下载 `v0.1.0-full`。  
**效果站：** https://wesker8088.github.io/motion-styles/  
**安装页：** https://wesker8088.github.io/motion-styles/install.html

## 本包含什么

- `references/intake.md` — 开工 SOP（G1–G3）
- `references/craft.md` — 节奏、连续性、字效、easing、声画、渲染坑
- `references/styles.md` — **仅 12 个**免费风格完整条目
- `scripts/fingerprint.py` · `scripts/fetch_ref.sh` · `scripts/ref_sheet.sh`
- `templates/remotion-starter/` — 可拷贝的 Remotion 起步工程
- `LICENSE-*.md` — 第三方参考与样片许可摘要

## 免费 12 slug

editorial-thread · bold-kinetic-launch · kanji-op-titlecard · woodcut-one-accent · swiss-grid-motion · ui-components-alive · onetake-carry · pcb-silk-reel · dark-precision-product · dual-mode-explainer · powers-of-ten-3d · whiteboard-explainer

## 最小工作流

1. 读 `references/intake.md`，确认 brief（G1）。
2. 从上述 12 个 slug 里挑方向（G2）；`bash scripts/fetch_ref.sh <slug>` 看帧与 clip。
3. 拷 `templates/remotion-starter`，按 DNA 做 10–12 s 小样（G3）。
4. `python scripts/fingerprint.py out/sample.mp4` 自检节奏/亮度漂移。

需要更多风格、完整 DNA 库与进阶模板时，到安装页用兑换码解锁全量包，解压覆盖/替换本目录即可（目录名仍须为 `motion-video-styles`）。
