import { continueRender, delayRender, staticFile } from "remotion";

// Default palette = "editorial-thread": paper, ink, one accent. Swap per style (see references/styles.md).
export const C = {
  paper: "#F2EFE8",
  ink: "#141414",
  stone: "#8A857B",
  rule: "rgba(20,20,20,0.12)",
  accent: "#E8462B",
};

export const F = {
  sc: '"SC", "Noto Sans CJK SC", sans-serif',
  latin: '"Geist", "SC", sans-serif',
  mono: '"GeistMono", "SC", monospace',
};

// Fonts live in public/fonts (see SKILL.md → fonts). Big CJK fonts load slowly:
// render with --timeout=180000 and --concurrency<=4 or delayRender will time out.
const loadFont = (family: string, file: string, weight = "100 900") => {
  if (typeof document === "undefined") return;
  const handle = delayRender(`Loading font ${family}`);
  const face = new FontFace(family, `url(${staticFile(file)})`, { weight });
  face
    .load()
    .then(() => {
      document.fonts.add(face);
      continueRender(handle);
    })
    .catch((err) => {
      console.error(err);
      continueRender(handle);
    });
};

loadFont("SC", "fonts/NotoSansSC-VF.ttf");
loadFont("Geist", "fonts/Geist-VF.ttf");
loadFont("GeistMono", "fonts/GeistMono-VF.ttf");
