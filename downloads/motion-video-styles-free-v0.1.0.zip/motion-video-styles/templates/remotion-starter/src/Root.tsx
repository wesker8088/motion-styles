import { Composition } from "remotion";
import { FILM_FRAMES, Film } from "./Film";
import TL from "./timeline.json";

// One composition per delivery format. Layout code reads useLayout().P to adapt.
export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Film" component={Film} durationInFrames={FILM_FRAMES} fps={TL.fps} width={TL.width} height={TL.height} />
    <Composition id="FilmAlt" component={Film} durationInFrames={FILM_FRAMES} fps={TL.fps} width={TL.height} height={TL.width} />
  </>
);
