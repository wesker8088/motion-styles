import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame } from "remotion";
import { Fade, Reveal, expoOut, inOut, mix, prog, useLayout } from "./motion";
import { C, F } from "./theme";
import TL from "./timeline.json";

// Starter film in the "editorial-thread" style: paper + ink + one accent line that
// carries the eye from section to section. Every timing comes from timeline.json,
// which scripts/music.py also reads, so picture and sound stay on the same beat grid.

const FPS = TL.fps;
export const FILM_FRAMES = TL.duration * FPS;
const fr = (s: number) => Math.round(s * FPS);
type Sec = { id: string; start: number; dur: number } & Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
const SEC = Object.fromEntries(TL.sections.map((s) => [s.id, s as Sec])) as Record<string, Sec>;

// ------------------------------------------------------------------ texture + chrome
const Paper: React.FC = () => (
  <AbsoluteFill style={{ background: C.paper }}>
    <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, opacity: 0.07, mixBlendMode: "multiply" }}>
      <filter id="grain">
        <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="3" stitchTiles="stitch" />
        <feColorMatrix type="saturate" values="0" />
      </filter>
      <rect width="100%" height="100%" filter="url(#grain)" />
    </svg>
  </AbsoluteFill>
);

// Persistent element: a quiet footer that ties all shots together.
const Footer: React.FC<{ label: string }> = ({ label }) => {
  const frame = useCurrentFrame();
  const { P } = useLayout();
  const s = Math.floor(frame / FPS);
  const mmss = (x: number) => `${String(Math.floor(x / 60)).padStart(2, "0")}:${String(x % 60).padStart(2, "0")}`;
  return (
    <div
      style={{
        position: "absolute",
        left: P ? 90 : 120,
        right: P ? 90 : 120,
        bottom: P ? 110 : 64,
        display: "flex",
        justifyContent: "space-between",
        fontFamily: F.mono,
        fontSize: 20,
        letterSpacing: 2,
        color: C.stone,
        opacity: prog(frame, fr(2.5), 20),
      }}
    >
      <span style={{ fontFamily: F.sc, fontWeight: 500, letterSpacing: 4 }}>{label}</span>
      <span>
        {mmss(s)} <span style={{ opacity: 0.5 }}>/ {mmss(TL.duration)}</span>
      </span>
    </div>
  );
};

// ------------------------------------------------------------------ the thread
type Rect = { x: number; y: number; w: number; h: number };
const lerpRect = (a: Rect, b: Rect, t: number): Rect => ({ x: mix(a.x, b.x, t), y: mix(a.y, b.y, t), w: mix(a.w, b.w, t), h: mix(a.h, b.h, t) });
const stub = (r: Rect): Rect => ({ x: r.x, y: r.y, w: 4, h: 4 });

const Thread: React.FC = () => {
  const frame = useCurrentFrame();
  const { P, W, H } = useLayout();
  const L = P ? 90 : 240;
  const cy = P ? 1010 : H * 0.6;
  const line: Rect = { x: L, y: cy - 2, w: W - 2 * L, h: 4 };
  const rule: Rect = { x: L, y: P ? 600 : 300, w: 4, h: P ? 700 : 480 };
  const o = SEC.open;
  if (frame < fr(o.dot)) return null;

  let r: Rect;
  const f = frame - fr(SEC.point.start);
  if (f < 0) {
    const d = 9 * prog(frame, fr(o.dot), 14);
    const dot = { x: W / 2 - d, y: cy - d, w: 2 * d, h: 2 * d };
    r = lerpRect(dot, line, prog(frame, fr(o.line), 26));
  } else if (f < 12) {
    // fold in two steps — never lerp width and height together (it becomes a fat slab)
    r = lerpRect(line, stub(line), prog(f, 0, 12, inOut));
  } else {
    r = lerpRect(stub(rule), rule, prog(f, 12, 18, expoOut));
  }
  const round = r.w < 24 && r.h < 24;
  return <div style={{ position: "absolute", left: r.x, top: r.y, width: r.w, height: r.h, background: C.accent, borderRadius: round ? 999 : 2 }} />;
};

// ------------------------------------------------------------------ giant one-char-per-beat cuts
const Giants: React.FC<{ chars: string[]; times: number[] }> = ({ chars, times }) => {
  const f = useCurrentFrame();
  let i = -1;
  times.forEach((t, k) => f >= fr(t) && (i = k));
  if (i < 0 || f >= fr(times[times.length - 1] + 0.5)) return null;
  const local = f - fr(times[i]);
  const s = mix(1.1, 1, prog(local, 0, 10));
  const off = mix(26, 12, prog(local, 0, 10));
  const glyph: React.CSSProperties = { position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 820, fontWeight: 900 };
  return (
    <AbsoluteFill style={{ transform: `scale(${s})` }}>
      <div style={{ ...glyph, color: C.accent, transform: `translate(${off}px, ${off * 0.6}px)` }}>{chars[i]}</div>
      <div style={{ ...glyph, color: C.ink, mixBlendMode: "multiply" }}>{chars[i]}</div>
    </AbsoluteFill>
  );
};

const Kicker: React.FC<{ index: string; label: string; at: number; out?: number }> = ({ index, label, at, out }) => (
  <div style={{ display: "flex", gap: 18, alignItems: "baseline", fontSize: 26 }}>
    <Reveal at={at} out={out}>
      <span style={{ color: C.accent, fontFamily: F.mono }}>{index}</span>
    </Reveal>
    <Reveal at={at + 3} out={out}>
      <span style={{ color: C.stone, fontWeight: 500, letterSpacing: 4 }}>{label}</span>
    </Reveal>
  </div>
);

// ------------------------------------------------------------------ sections (replace with your story)
const Open: React.FC = () => {
  const s = SEC.open;
  const out = fr(s.dur) - 15;
  const { P } = useLayout();
  const top = P ? 760 : 330;
  return (
    <AbsoluteFill>
      <Giants chars={["一", "条", "线", "索"]} times={s.hits} />
      <div style={{ position: "absolute", left: 0, right: 0, top: top - 70, textAlign: "center", fontSize: 30, fontWeight: 500, letterSpacing: 6, color: C.stone }}>
        <Reveal at={fr(s.kicker)} out={out}>
          副标题 · 机构名
        </Reveal>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top, textAlign: "center", fontSize: P ? 178 : 200, fontWeight: 900, letterSpacing: "-0.03em" }}>
        {["主标", "题词", "三拍"].map((w, i) => (
          <Reveal key={w} at={fr(s.words[i])} out={out + i * 2} dur={12}>
            {w}
          </Reveal>
        ))}
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: P ? 1052 : 700, textAlign: "center", fontSize: 34, fontWeight: 500, letterSpacing: 4 }}>
        <Reveal at={fr(s.lines[0])} out={out}>
          一句话说明
        </Reveal>
      </div>
    </AbsoluteFill>
  );
};

const Point: React.FC = () => {
  const s = SEC.point;
  const out = fr(s.dur) - 15;
  const { P } = useLayout();
  return (
    <div style={{ position: "absolute", left: (P ? 90 : 240) + 46, right: 90, top: P ? 594 : 294 }}>
      <Kicker index="01" label="要点" at={fr(s.kicker)} out={out} />
      <div style={{ fontSize: P ? 128 : 140, fontWeight: 900, letterSpacing: "-0.03em", lineHeight: 1.16, marginTop: 36 }}>
        {["每拍", "落下", "一个词"].map((w, i) => (
          <div key={w}>
            <Reveal at={fr(s.words[i])} out={out + i * 2}>
              {w}
            </Reveal>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 50, display: "flex", flexDirection: "column", gap: 20 }}>
        {["补充说明一", "补充说明二"].map((t, i) => (
          <Fade key={t} at={fr(s.items[i])} out={out}>
            <div style={{ fontSize: 34, fontWeight: 500, color: "rgba(20,20,20,0.75)" }}>{t}</div>
          </Fade>
        ))}
      </div>
    </div>
  );
};

const VIEWS: Record<string, React.FC> = { open: Open, point: Point };

export const Film: React.FC = () => (
  <AbsoluteFill style={{ color: C.ink, fontFamily: F.sc }}>
    <Paper />
    <Audio src={staticFile("music/film.wav")} />
    {TL.sections.map((s) => {
      const View = VIEWS[s.id];
      return (
        <Sequence key={s.id} from={fr(s.start)} durationInFrames={fr(s.dur)} name={s.id}>
          <View />
        </Sequence>
      );
    })}
    <Thread />
    <Footer label="机构名 · 项目名" />
  </AbsoluteFill>
);
