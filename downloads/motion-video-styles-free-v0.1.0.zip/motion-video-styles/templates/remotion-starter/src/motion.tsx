import { Easing, interpolate, useCurrentFrame, useVideoConfig } from "remotion";

// Critically damped feel: fast start, long soft settle, no overshoot.
export const expoOut = Easing.bezier(0.16, 1, 0.3, 1);
export const inOut = Easing.bezier(0.65, 0, 0.35, 1);
export const expoIn = Easing.bezier(0.7, 0, 0.84, 0);

export const prog = (frame: number, start: number, dur: number, ease = expoOut) =>
  interpolate(frame, [start, start + dur], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });

export const mix = (a: number, b: number, t: number) => a + (b - a) * t;

export const useLayout = () => {
  const { width, height } = useVideoConfig();
  return { P: height > width, W: width, H: height };
};

// Masked slide-up reveal (and optional masked exit upward).
export const Reveal: React.FC<{
  at: number;
  out?: number;
  dur?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ at, out, dur = 14, children, style }) => {
  const frame = useCurrentFrame();
  const i = prog(frame, at, dur);
  const o = out === undefined ? 0 : prog(frame, out, 12, expoIn);
  return (
    <span style={{ display: "inline-block", overflow: "hidden", verticalAlign: "bottom", paddingBottom: "0.08em", ...style }}>
      <span style={{ display: "inline-block", transform: `translateY(${(1 - i) * 105 - o * 105}%)` }}>{children}</span>
    </span>
  );
};

export const Fade: React.FC<{ at: number; out?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({
  at,
  out,
  children,
  style,
}) => {
  const frame = useCurrentFrame();
  const o = prog(frame, at, 16) * (out === undefined ? 1 : 1 - prog(frame, out, 10, expoIn));
  return <div style={{ opacity: o, transform: `translateY(${(1 - prog(frame, at, 16)) * 12}px)`, ...style }}>{children}</div>;
};
