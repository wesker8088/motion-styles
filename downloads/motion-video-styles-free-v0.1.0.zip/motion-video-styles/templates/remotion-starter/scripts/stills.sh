#!/usr/bin/env bash
# Render keyframes (seconds as args, default: 1s before the end of every section) and tile them
# into out/stills/sheet.png for a one-glance review. Usage: bash scripts/stills.sh [comp] [t1 t2 ...]
set -euo pipefail
cd "$(dirname "$0")/.."
COMP="${1:-Film}"; shift || true
mkdir -p out/stills && rm -f "out/stills/$COMP"-*.png
TIMES="${*:-$(python3 -c "import json;t=json.load(open('src/timeline.json'));print(' '.join(str(s['start']+s['dur']-1) for s in t['sections']))")}"
FPS=$(python3 -c "import json;print(json.load(open('src/timeline.json'))['fps'])")
nice -n 15 npx remotion bundle --out-dir=build --log=error >/dev/null
for t in $TIMES; do
  f=$(python3 -c "print(round($t*$FPS))")
  nice -n 15 npx remotion still build "$COMP" "out/stills/$COMP-$f.png" --frame="$f" --timeout=180000 --log=error >/dev/null
done
L=$(ls out/stills/"$COMP"-*.png | sort -t- -k2 -n)
n=$(echo "$L" | wc -l)
ffmpeg -nostdin -y -loglevel error $(for f in $L; do echo -i "$f"; done) \
  -filter_complex "$(i=0; for f in $L; do echo -n "[$i]scale=480:480:force_original_aspect_ratio=decrease,pad=480:480:(ow-iw)/2:(oh-ih)/2:white[v$i];"; i=$((i+1)); done)$(for i in $(seq 0 $((n-1))); do echo -n "[v$i]"; done)xstack=inputs=$n:layout=$(python3 -c "
n=$n;c=min(4,n);print('|'.join(f'{(i%c)*480}_{(i//c)*480}' for i in range(n)))")" "out/stills/sheet-$COMP.png" 2>/dev/null || true
echo "stills -> out/stills/ (sheet-$COMP.png)"
