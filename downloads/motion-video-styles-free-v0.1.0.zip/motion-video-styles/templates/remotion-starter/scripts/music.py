"""Original minimal electronic score generated from src/timeline.json (numpy only, no samples,
no licensing questions). Every on-screen reveal in the timeline gets a pluck, so picture and
sound share one beat grid.

  python3 scripts/music.py            -> public/music/film.wav
  then loudness-normalise: npm run music (does both)

Timeline keys understood per section (seconds, relative to section start):
  words/items/lines : reveals -> pluck            hits : giant-char cuts -> impact
  kicker / dot      : small tick                  line : swish
  num               : impact + high pluck         section start (not first) : swish
  swishes / impacts / dings : extra whoosh / hit / bright-ding cues (whip-pans, lightning, arrows)
Top level: bpm, duration, stills [[a,b],...] (drums/bass drop out = silence on picture),
           groove_from (seconds; when drums/bass enter).
"""
import wave
from pathlib import Path

import numpy as np

SR = 48000
rng = np.random.default_rng(11)


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def fft_filter(x, lo=None, hi=None, order=2):
    X = np.fft.rfft(x, axis=-1)
    f = np.fft.rfftfreq(x.shape[-1], 1 / SR)
    H = np.ones_like(f)
    if hi:
        H /= np.sqrt(1 + (f / hi) ** (2 * order))
    if lo:
        H /= np.sqrt(1 + (lo / np.maximum(f, 1e-3)) ** (2 * order))
    return np.fft.irfft(X * H, n=x.shape[-1], axis=-1)


class Track:
    def __init__(self, dur):
        self.n = int(dur * SR)
        self.bus = {k: np.zeros((2, self.n)) for k in ("pad", "bass", "drums", "keys", "fx")}

    def add(self, bus, sig, t0, pan=0.0, gain=1.0):
        i0 = int(round(t0 * SR))
        if i0 >= self.n or i0 < 0:
            return
        sig = sig[: self.n - i0]
        th = (pan + 1) * np.pi / 4
        self.bus[bus][0, i0 : i0 + len(sig)] += sig * np.cos(th) * gain
        self.bus[bus][1, i0 : i0 + len(sig)] += sig * np.sin(th) * gain


def tt(dur):
    return np.arange(int(dur * SR)) / SR


def pluck(f, dur=1.2):
    t = tt(dur)
    s = np.zeros_like(t)
    for k, a in [(1, 1.0), (2, 0.35), (3, 0.12), (4.2, 0.06)]:
        s += a * np.sin(2 * np.pi * f * k * t) * np.exp(-t * (5 + 3 * k))
    return s * np.minimum(1, t / 0.003)


def pad(fs, dur, attack=1.2, release=1.5):
    t = tt(dur)
    s = np.zeros_like(t)
    for f in fs:
        for det in (-0.004, 0.004):
            for k in range(1, 6):
                s += np.sin(2 * np.pi * f * (1 + det) * k * t + rng.uniform(0, 6.28)) / k**1.6
    env = np.minimum(1, t / attack) * np.clip((dur - t) / release, 0, 1)
    return s * env / (len(fs) * 4)


def kick(g=1.0):
    t = tt(0.4)
    fr = 42 + 80 * np.exp(-t * 32)
    return g * np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 9)


def hat(g=1.0):
    t = tt(0.06)
    return g * fft_filter(rng.standard_normal(len(t)), lo=8000) * np.exp(-t * 70)


def tick():
    t = tt(0.05)
    return np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 120)


def swish(dur=0.6, up=True):
    t = tt(dur)
    x = fft_filter(rng.standard_normal(len(t)), lo=600, hi=7000)
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return x * env * 0.5


def sub(f, dur):
    t = tt(dur)
    return np.sin(2 * np.pi * f * t) * np.minimum(1, t / 0.02) * np.clip((dur - t) / 0.08, 0, 1)


def reverb(x, secs=2.2, decay=0.6):
    n = int(secs * SR)
    t = np.arange(n) / SR
    ir = np.stack([rng.standard_normal(n), rng.standard_normal(n)]) * np.exp(-t / decay)
    ir = fft_filter(ir, hi=6000)
    ir /= np.sqrt((ir**2).sum(axis=1, keepdims=True))
    L = 1 << int(np.ceil(np.log2(x.shape[1] + n)))
    return np.fft.irfft(np.fft.rfft(x, L, axis=1) * np.fft.rfft(ir, L, axis=1), L, axis=1)[:, : x.shape[1]]


def master(tr, out, fade_out=0.5):
    b = tr.bus
    dry = b["pad"] * 0.8 + b["bass"] + b["drums"] + b["keys"] + b["fx"]
    wet = reverb(0.5 * b["keys"] + 0.3 * b["pad"] + 0.25 * b["fx"])
    mix = fft_filter(dry + 0.3 * wet, lo=28)
    t = np.arange(tr.n) / SR
    dur = tr.n / SR
    mix *= np.interp(t, [0, 0.02, dur - fade_out, dur], [0, 1, 1, 0])
    mix /= np.abs(mix).max() + 1e-9
    mix = np.tanh(mix * 1.2) / np.tanh(1.2) * 0.89
    pcm = (mix.T * 32767).astype(np.int16)
    with wave.open(str(out), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("wrote", out)


def impact(g=1.0):
    t = tt(1.2)
    body = np.sin(2 * np.pi * np.cumsum(36 + 110 * np.exp(-t * 18)) / SR) * np.exp(-t * 4.5)
    snap = fft_filter(rng.standard_normal(len(t)), lo=1200, hi=9000) * np.exp(-t * 30) * 0.35
    return g * (body + snap)


# chord loop (2 bars each): Am9, Fmaj9, Cmaj9, G6sus — calm, modern, non-cheesy
CHORDS = [[57, 60, 64, 67, 71], [53, 57, 60, 64, 67], [48, 52, 55, 59, 62], [55, 59, 62, 64, 69]]
ROOTS = [45, 41, 48, 43]
PENT = [69, 72, 74, 76, 79, 81, 84]  # A minor pentatonic for plucks


def build():
    import json

    root = Path(__file__).resolve().parent.parent
    tl = json.loads((root / "src" / "timeline.json").read_text())
    dur = float(tl["duration"])
    beat = 60.0 / tl["bpm"]
    bar2 = beat * 8
    tr = Track(dur)
    stills = tl.get("stills", [])
    hit_windows, hits = [], []
    for s in tl["sections"]:
        for h in s.get("hits", []):
            hits.append(s["start"] + h)
        if s.get("hits"):
            hit_windows.append((s["start"], s["start"] + max(s["hits"]) + beat))

    def inside(t, ranges):
        return any(a <= t < b for a, b in ranges)

    for k, t0 in enumerate(np.arange(0, dur, bar2)):
        tr.add("pad", pad([midi(m) for m in CHORDS[k % 4]], bar2 + 0.8), t0, gain=0.75)

    # drums/bass start at timeline["groove_from"] if given (e.g. after a quiet intro), else at the first "line" cue or 0
    groove_from = tl.get("groove_from", min([s["start"] + s["line"] for s in tl["sections"] if "line" in s] + [0.0]))
    for i in range(int(np.ceil(groove_from / beat)), int(dur / beat)):
        t = i * beat
        if inside(t, stills) or inside(t, hit_windows):
            continue
        if i % 2 == 0:
            tr.add("drums", kick(0.85), t)
        tr.add("drums", hat(0.09), t + beat / 2, pan=0.3)
        tr.add("drums", hat(0.04), t, pan=-0.3)
        tr.add("bass", sub(midi(ROOTS[int(t // bar2) % 4] - 12), beat * 0.85), t, gain=0.4)

    for t in hits:
        tr.add("drums", impact(0.9), t)

    for n, s in enumerate(tl["sections"]):
        st = s["start"]
        if n > 0:
            tr.add("fx", swish(0.8), st - 0.25, gain=0.45)
        for key in ("kicker", "dot"):
            if key in s:
                tr.add("fx", tick(), st + s[key], gain=0.3)
        if "line" in s:
            tr.add("fx", swish(0.7), st + s["line"] - 0.2, gain=0.5)
        times = sorted(st + x for key in ("words", "items", "lines") for x in s.get(key, []))
        for k, t in enumerate(times):
            tr.add("keys", pluck(midi(PENT[k % len(PENT)])), t, gain=0.42, pan=0.15 if k % 2 else -0.15)
        for x in s.get("swishes", []):
            tr.add("fx", swish(0.6), st + x - 0.15, gain=0.55)
        for x in s.get("dings", []):
            tr.add("keys", pluck(midi(93), 0.8), st + x, gain=0.35)
        for x in s.get("impacts", []):
            tr.add("drums", impact(0.85), st + x)
        if "num" in s:
            tr.add("drums", impact(0.75), st + s["num"])
            tr.add("keys", pluck(midi(88), 2.0), st + s["num"], gain=0.25)

    for a, _ in stills:
        tr.add("keys", pluck(midi(84), 2.0), a - 0.5, gain=0.22)

    out = root / "public" / "music" / "film.wav"
    out.parent.mkdir(parents=True, exist_ok=True)
    master(tr, out, fade_out=1.5)


if __name__ == "__main__":
    build()
