#!/usr/bin/env bash
# Fetch OFL fonts into public/fonts: Noto Sans SC (variable 100–900), Geist, Geist Mono.
set -euo pipefail
cd "$(dirname "$0")/../public/fonts"
get() { [ -s "$2" ] || curl -fsSL --retry 2 --max-time 300 -o "$2" "$1"; }
get "https://github.com/google/fonts/raw/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf" NotoSansSC-VF.ttf
get "https://github.com/google/fonts/raw/main/ofl/geist/Geist%5Bwght%5D.ttf" Geist-VF.ttf
get "https://github.com/google/fonts/raw/main/ofl/geistmono/GeistMono%5Bwght%5D.ttf" GeistMono-VF.ttf
ls -la
